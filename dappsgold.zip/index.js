let Link1 = document.getElementById("link-1");
let img1 = document.getElementById("img-1");
let text1 = document.getElementById("text-1");
Link1.addEventListener("mouseover", hoverFunction1);
Link1.addEventListener("mouseout", hoverFunction1);
function hoverFunction1() {
  img1.classList.toggle("box-shadow");
  text1.classList.toggle("blue-text");
}

let Link2 = document.getElementById("link-2");
Link2.addEventListener("mouseover", hoverFunction2);
Link2.addEventListener("mouseout", hoverFunction2);
let img2 = document.getElementById("img-2");
let text2 = document.getElementById("text-2");
function hoverFunction2() {
  img2.classList.toggle("box-shadow");
  text2.classList.toggle("blue-text");
}
let Link3 = document.getElementById("link-3");
Link3.addEventListener("mouseover", hoverFunction3);
Link3.addEventListener("mouseout", hoverFunction3);
let img3 = document.getElementById("img-3");
let text3 = document.getElementById("text-3");
function hoverFunction3() {
  img3.classList.toggle("box-shadow");
  text3.classList.toggle("blue-text");
}

let Link4 = document.getElementById("link-4");
Link4.addEventListener("mouseover", hoverFunction4);
Link4.addEventListener("mouseout", hoverFunction4);
let img4 = document.getElementById("img-4");
let text4 = document.getElementById("text-4");
function hoverFunction4() {
  img4.classList.toggle("box-shadow");
  text4.classList.toggle("blue-text");
}

let Link5 = document.getElementById("link-5");
Link5.addEventListener("mouseover", hoverFunction5);
Link5.addEventListener("mouseout", hoverFunction5);
let img5 = document.getElementById("img-5");
let text5 = document.getElementById("text-5");
function hoverFunction5() {
  img5.classList.toggle("box-shadow");
  text5.classList.toggle("blue-text");
}

let Link6 = document.getElementById("link-6");
Link6.addEventListener("mouseover", hoverFunction6);
Link6.addEventListener("mouseout", hoverFunction6);
let img6 = document.getElementById("img-6");
let text6 = document.getElementById("text-6");
function hoverFunction6() {
  img6.classList.toggle("box-shadow");
  text6.classList.toggle("blue-text");
}
let Link7 = document.getElementById("link-7");
Link7.addEventListener("mouseover", hoverFunction7);
Link7.addEventListener("mouseout", hoverFunction7);
let img7 = document.getElementById("img-7");
let text7 = document.getElementById("text-7");
function hoverFunction7() {
  img7.classList.toggle("box-shadow");
  text7.classList.toggle("blue-text");
}
let Link8 = document.getElementById("link-8");
Link8.addEventListener("mouseover", hoverFunction8);
Link8.addEventListener("mouseout", hoverFunction8);
let img8 = document.getElementById("img-8");
let text8 = document.getElementById("text-8");
function hoverFunction8() {
  img8.classList.toggle("box-shadow");
  text8.classList.toggle("blue-text");
}
let Link9 = document.getElementById("link-9");
Link9.addEventListener("mouseover", hoverFunction9);
Link9.addEventListener("mouseout", hoverFunction9);
let img9 = document.getElementById("img-9");
let text9 = document.getElementById("text-9");
function hoverFunction9() {
  img9.classList.toggle("box-shadow");
  text9.classList.toggle("blue-text");
}
let Link10 = document.getElementById("link-10");
Link10.addEventListener("mouseover", hoverFunction10);
Link10.addEventListener("mouseout", hoverFunction10);
let img10 = document.getElementById("img-10");
let text10 = document.getElementById("text-10");
function hoverFunction10() {
  img10.classList.toggle("box-shadow");
  text10.classList.toggle("blue-text");
}
let Link11 = document.getElementById("link-11");
Link11.addEventListener("mouseover", hoverFunction11);
Link11.addEventListener("mouseout", hoverFunction11);
let img11 = document.getElementById("img-11");
let text11 = document.getElementById("text-11");
function hoverFunction11() {
  img11.classList.toggle("box-shadow");
  text11.classList.toggle("blue-text");
}
let Link12 = document.getElementById("link-12");
Link12.addEventListener("mouseover", hoverFunction12);
Link12.addEventListener("mouseout", hoverFunction12);
let img12 = document.getElementById("img-12");
let text12 = document.getElementById("text-12");
function hoverFunction12() {
  img12.classList.toggle("box-shadow");
  text12.classList.toggle("blue-text");
}
let Link13 = document.getElementById("link-13");
Link13.addEventListener("mouseover", hoverFunction13);
Link13.addEventListener("mouseout", hoverFunction13);
let img13 = document.getElementById("img-13");
let text13 = document.getElementById("text-13");
function hoverFunction13() {
  img13.classList.toggle("box-shadow");
  text13.classList.toggle("blue-text");
}
let Link14 = document.getElementById("link-14");
Link14.addEventListener("mouseover", hoverFunction14);
Link14.addEventListener("mouseout", hoverFunction14);
let img14 = document.getElementById("img-14");
let text14 = document.getElementById("text-14");
function hoverFunction14() {
  img14.classList.toggle("box-shadow");
  text14.classList.toggle("blue-text");
}
let Link15 = document.getElementById("link-15");
Link15.addEventListener("mouseover", hoverFunction15);
Link15.addEventListener("mouseout", hoverFunction15);
let img15 = document.getElementById("img-15");
let text15 = document.getElementById("text-15");
function hoverFunction15() {
  img15.classList.toggle("box-shadow");
  text15.classList.toggle("blue-text");
}
let Link16 = document.getElementById("link-16");
Link16.addEventListener("mouseover", hoverFunction16);
Link16.addEventListener("mouseout", hoverFunction16);
let img16 = document.getElementById("img-16");
let text16 = document.getElementById("text-16");
function hoverFunction16() {
  img16.classList.toggle("box-shadow");
  text16.classList.toggle("blue-text");
}
let Link17 = document.getElementById("link-17");
Link17.addEventListener("mouseover", hoverFunction17);
Link17.addEventListener("mouseout", hoverFunction17);
let img17 = document.getElementById("img-17");
let text17 = document.getElementById("text-17");
function hoverFunction17() {
  img17.classList.toggle("box-shadow");
  text17.classList.toggle("blue-text");
}
let Link18 = document.getElementById("link-18");
Link18.addEventListener("mouseover", hoverFunction18);
Link18.addEventListener("mouseout", hoverFunction18);
let img18 = document.getElementById("img-18");
let text18 = document.getElementById("text-18");
function hoverFunction18() {
  img18.classList.toggle("box-shadow");
  text18.classList.toggle("blue-text");
}
let Link19 = document.getElementById("link-19");
Link19.addEventListener("mouseover", hoverFunction19);
Link19.addEventListener("mouseout", hoverFunction19);
let img19 = document.getElementById("img-19");
let text19 = document.getElementById("text-19");
function hoverFunction19() {
  img19.classList.toggle("box-shadow");
  text19.classList.toggle("blue-text");
}
let Link20 = document.getElementById("link-20");
Link20.addEventListener("mouseover", hoverFunction20);
Link20.addEventListener("mouseout", hoverFunction20);
let img20 = document.getElementById("img-20");
let text20 = document.getElementById("text-20");
function hoverFunction20() {
  img20.classList.toggle("box-shadow");
  text20.classList.toggle("blue-text");
}
let Link21 = document.getElementById("link-21");
Link21.addEventListener("mouseover", hoverFunction21);
Link21.addEventListener("mouseout", hoverFunction21);
let img21 = document.getElementById("img-21");
let text21 = document.getElementById("text-21");
function hoverFunction21() {
  img21.classList.toggle("box-shadow");
  text21.classList.toggle("blue-text");
}
let Link22 = document.getElementById("link-22");
Link22.addEventListener("mouseover", hoverFunction22);
Link22.addEventListener("mouseout", hoverFunction22);
let img22 = document.getElementById("img-22");
let text22 = document.getElementById("text-22");
function hoverFunction22() {
  img22.classList.toggle("box-shadow");
  text22.classList.toggle("blue-text");
}
let Link23 = document.getElementById("link-23");
Link23.addEventListener("mouseover", hoverFunction23);
Link23.addEventListener("mouseout", hoverFunction23);
let img23 = document.getElementById("img-23");
let text23 = document.getElementById("text-23");
function hoverFunction23() {
  img23.classList.toggle("box-shadow");
  text23.classList.toggle("blue-text");
}
let Link24 = document.getElementById("link-24");
Link24.addEventListener("mouseover", hoverFunction24);
Link24.addEventListener("mouseout", hoverFunction24);
let img24 = document.getElementById("img-24");
let text24 = document.getElementById("text-24");
function hoverFunction24() {
  img24.classList.toggle("box-shadow");
  text24.classList.toggle("blue-text");
}
let Link25 = document.getElementById("link-25");
Link25.addEventListener("mouseover", hoverFunction25);
Link25.addEventListener("mouseout", hoverFunction25);
let img25 = document.getElementById("img-25");
let text25 = document.getElementById("text-25");
function hoverFunction25() {
  img25.classList.toggle("box-shadow");
  text25.classList.toggle("blue-text");
}
let Link26 = document.getElementById("link-26");
Link26.addEventListener("mouseover", hoverFunction26);
Link26.addEventListener("mouseout", hoverFunction26);
let img26 = document.getElementById("img-26");
let text26 = document.getElementById("text-26");
function hoverFunction26() {
  img26.classList.toggle("box-shadow");
  text26.classList.toggle("blue-text");
}
let Link27 = document.getElementById("link-27");
Link27.addEventListener("mouseover", hoverFunction27);
Link27.addEventListener("mouseout", hoverFunction27);
let img27 = document.getElementById("img-27");
let text27 = document.getElementById("text-27");
function hoverFunction27() {
  img27.classList.toggle("box-shadow");
  text27.classList.toggle("blue-text");
}
let Link28 = document.getElementById("link-28");
Link28.addEventListener("mouseover", hoverFunction28);
Link28.addEventListener("mouseout", hoverFunction28);
let img28 = document.getElementById("img-28");
let text28 = document.getElementById("text-28");
function hoverFunction28() {
  img28.classList.toggle("box-shadow");
  text28.classList.toggle("blue-text");
}
let Link29 = document.getElementById("link-29");
Link29.addEventListener("mouseover", hoverFunction29);
Link29.addEventListener("mouseout", hoverFunction29);
let img29 = document.getElementById("img-29");
let text29 = document.getElementById("text-29");
function hoverFunction29() {
  img29.classList.toggle("box-shadow");
  text29.classList.toggle("blue-text");
}
let Link30 = document.getElementById("link-30");
Link30.addEventListener("mouseover", hoverFunction30);
Link30.addEventListener("mouseout", hoverFunction30);
let img30 = document.getElementById("img-30");
let text30 = document.getElementById("text-30");
function hoverFunction30() {
  img30.classList.toggle("box-shadow");
  text30.classList.toggle("blue-text");
}
let Link31 = document.getElementById("link-31");
Link31.addEventListener("mouseover", hoverFunction31);
Link31.addEventListener("mouseout", hoverFunction31);
let img31 = document.getElementById("img-31");
let text31 = document.getElementById("text-31");
function hoverFunction31() {
  img31.classList.toggle("box-shadow");
  text31.classList.toggle("blue-text");
}
let Link32 = document.getElementById("link-32");
Link32.addEventListener("mouseover", hoverFunction32);
Link32.addEventListener("mouseout", hoverFunction32);
let img32 = document.getElementById("img-32");
let text32 = document.getElementById("text-32");
function hoverFunction32() {
  img32.classList.toggle("box-shadow");
  text32.classList.toggle("blue-text");
}
let Link33 = document.getElementById("link-33");
Link33.addEventListener("mouseover", hoverFunction33);
Link33.addEventListener("mouseout", hoverFunction33);
let img33 = document.getElementById("img-33");
let text33 = document.getElementById("text-33");
function hoverFunction33() {
  img33.classList.toggle("box-shadow");
  text33.classList.toggle("blue-text");
}
let Link34 = document.getElementById("link-34");
Link34.addEventListener("mouseover", hoverFunction34);
Link34.addEventListener("mouseout", hoverFunction34);
let img34 = document.getElementById("img-34");
let text34 = document.getElementById("text-34");
function hoverFunction34() {
  img34.classList.toggle("box-shadow");
  text34.classList.toggle("blue-text");
}
let Link35 = document.getElementById("link-35");
Link35.addEventListener("mouseover", hoverFunction35);
Link35.addEventListener("mouseout", hoverFunction35);
let img35 = document.getElementById("img-35");
let text35 = document.getElementById("text-35");
function hoverFunction35() {
  img35.classList.toggle("box-shadow");
  text35.classList.toggle("blue-text");
}
let Link36 = document.getElementById("link-36");
Link36.addEventListener("mouseover", hoverFunction36);
Link36.addEventListener("mouseout", hoverFunction36);
let img36 = document.getElementById("img-36");
let text36 = document.getElementById("text-36");
function hoverFunction36() {
  img36.classList.toggle("box-shadow");
  text36.classList.toggle("blue-text");
}
let Link37 = document.getElementById("link-37");
Link37.addEventListener("mouseover", hoverFunction37);
Link37.addEventListener("mouseout", hoverFunction37);
let img37 = document.getElementById("img-37");
let text37 = document.getElementById("text-37");
function hoverFunction37() {
  img37.classList.toggle("box-shadow");
  text37.classList.toggle("blue-text");
}
let Link38 = document.getElementById("link-38");
Link38.addEventListener("mouseover", hoverFunction38);
Link38.addEventListener("mouseout", hoverFunction38);
let img38 = document.getElementById("img-38");
let text38 = document.getElementById("text-38");
function hoverFunction38() {
  img38.classList.toggle("box-shadow");
  text38.classList.toggle("blue-text");
}
let Link39 = document.getElementById("link-39");
Link39.addEventListener("mouseover", hoverFunction39);
Link39.addEventListener("mouseout", hoverFunction39);
let img39 = document.getElementById("img-39");
let text39 = document.getElementById("text-39");
function hoverFunction39() {
  img39.classList.toggle("box-shadow");
  text39.classList.toggle("blue-text");
}
let Link40 = document.getElementById("link-40");
Link40.addEventListener("mouseover", hoverFunction4);
Link40.addEventListener("mouseout", hoverFunction40);
let img40 = document.getElementById("img-40");
let text40 = document.getElementById("text-40");
function hoverFunction40() {
  img40.classList.toggle("box-shadow");
  text40.classList.toggle("blue-text");
}
let Link41 = document.getElementById("link-41");
Link41.addEventListener("mouseover", hoverFunction41);
Link41.addEventListener("mouseout", hoverFunction41);
let img41 = document.getElementById("img-41");
let text41 = document.getElementById("text-41");
function hoverFunction41() {
  img41.classList.toggle("box-shadow");
  text41.classList.toggle("blue-text");
}
let Link42 = document.getElementById("link-42");
Link42.addEventListener("mouseover", hoverFunction42);
Link42.addEventListener("mouseout", hoverFunction42);
let img42 = document.getElementById("img-42");
let text42 = document.getElementById("text-42");
function hoverFunction42() {
  img42.classList.toggle("box-shadow");
  text42.classList.toggle("blue-text");
}
let Link43 = document.getElementById("link-43");
Link43.addEventListener("mouseover", hoverFunction43);
Link43.addEventListener("mouseout", hoverFunction43);
let img43 = document.getElementById("img-43");
let text43 = document.getElementById("text-43");
function hoverFunction43() {
  img43.classList.toggle("box-shadow");
  text43.classList.toggle("blue-text");
}
let Link44 = document.getElementById("link-44");
Link44.addEventListener("mouseover", hoverFunction44);
Link44.addEventListener("mouseout", hoverFunction44);
let img44 = document.getElementById("img-44");
let text44 = document.getElementById("text-44");
function hoverFunction44() {
  img44.classList.toggle("box-shadow");
  text44.classList.toggle("blue-text");
}
let Link45 = document.getElementById("link-45");
Link45.addEventListener("mouseover", hoverFunction45);
Link45.addEventListener("mouseout", hoverFunction45);
let img45 = document.getElementById("img-45");
let text45 = document.getElementById("text-45");
function hoverFunction45() {
  img45.classList.toggle("box-shadow");
  text45.classList.toggle("blue-text");
}
let Link46 = document.getElementById("link-46");
Link46.addEventListener("mouseover", hoverFunction46);
Link46.addEventListener("mouseout", hoverFunction46);
let img46 = document.getElementById("img-46");
let text46 = document.getElementById("text-46");
function hoverFunction46() {
  img46.classList.toggle("box-shadow");
  text46.classList.toggle("blue-text");
}
let Link47 = document.getElementById("link-47");
Link47.addEventListener("mouseover", hoverFunction47);
Link47.addEventListener("mouseout", hoverFunction47);
let img47 = document.getElementById("img-47");
let text47 = document.getElementById("text-47");
function hoverFunction47() {
  img47.classList.toggle("box-shadow");
  text47.classList.toggle("blue-text");
}
let Link48 = document.getElementById("link-48");
Link48.addEventListener("mouseover", hoverFunction48);
Link48.addEventListener("mouseout", hoverFunction48);
let img48 = document.getElementById("img-48");
let text48 = document.getElementById("text-48");
function hoverFunction48() {
  img48.classList.toggle("box-shadow");
  text48.classList.toggle("blue-text");
}
let Link49 = document.getElementById("link-49");
Link49.addEventListener("mouseover", hoverFunction49);
Link49.addEventListener("mouseout", hoverFunction49);
let img49 = document.getElementById("img-49");
let text49 = document.getElementById("text-49");
function hoverFunction49() {
  img49.classList.toggle("box-shadow");
  text49.classList.toggle("blue-text");
}
let Link50 = document.getElementById("link-50");
Link50.addEventListener("mouseover", hoverFunction50);
Link50.addEventListener("mouseout", hoverFunction50);
let img50 = document.getElementById("img-50");
let text50 = document.getElementById("text-50");
function hoverFunction50() {
  img50.classList.toggle("box-shadow");
  text50.classList.toggle("blue-text");
}
let Link51 = document.getElementById("link-51");
Link51.addEventListener("mouseover", hoverFunction51);
Link51.addEventListener("mouseout", hoverFunction51);
let img51 = document.getElementById("img-51");
let text51 = document.getElementById("text-51");
function hoverFunction51() {
  img51.classList.toggle("box-shadow");
  text51.classList.toggle("blue-text");
}
let Link52 = document.getElementById("link-52");
Link52.addEventListener("mouseover", hoverFunction52);
Link52.addEventListener("mouseout", hoverFunction52);
let img52 = document.getElementById("img-52");
let text52 = document.getElementById("text-52");
function hoverFunction52() {
  img52.classList.toggle("box-shadow");
  text52.classList.toggle("blue-text");
}
let Link53 = document.getElementById("link-53");
Link53.addEventListener("mouseover", hoverFunction53);
Link53.addEventListener("mouseout", hoverFunction53);
let img53 = document.getElementById("img-53");
let text53 = document.getElementById("text-53");
function hoverFunction53() {
  img53.classList.toggle("box-shadow");
  text53.classList.toggle("blue-text");
}
let Link54 = document.getElementById("link-54");
Link54.addEventListener("mouseover", hoverFunction44);
Link54.addEventListener("mouseout", hoverFunction54);
let img54 = document.getElementById("img-54");
let text54 = document.getElementById("text-54");
function hoverFunction54() {
  img54.classList.toggle("box-shadow");
  text54.classList.toggle("blue-text");
}
let Link55 = document.getElementById("link-55");
Link55.addEventListener("mouseover", hoverFunction55);
Link55.addEventListener("mouseout", hoverFunction55);
let img55 = document.getElementById("img-55");
let text55 = document.getElementById("text-55");
function hoverFunction55() {
  img55.classList.toggle("box-shadow");
  text55.classList.toggle("blue-text");
}
let Link56 = document.getElementById("link-56");
Link56.addEventListener("mouseover", hoverFunction56);
Link56.addEventListener("mouseout", hoverFunction56);
let img56 = document.getElementById("img-56");
let text56 = document.getElementById("text-56");
function hoverFunction56() {
  img56.classList.toggle("box-shadow");
  text56.classList.toggle("blue-text");
}
let Link57 = document.getElementById("link-57");
Link57.addEventListener("mouseover", hoverFunction57);
Link57.addEventListener("mouseout", hoverFunction57);
let img57 = document.getElementById("img-57");
let text57 = document.getElementById("text-57");
function hoverFunction57() {
  img57.classList.toggle("box-shadow");
  text57.classList.toggle("blue-text");
}
let Link58 = document.getElementById("link-58");
Link58.addEventListener("mouseover", hoverFunction58);
Link58.addEventListener("mouseout", hoverFunction58);
let img58 = document.getElementById("img-58");
let text58 = document.getElementById("text-58");
function hoverFunction58() {
  img58.classList.toggle("box-shadow");
  text58.classList.toggle("blue-text");
}

let Link59 = document.getElementById("link-59");
Link59.addEventListener("mouseover", hoverFunction59);
Link59.addEventListener("mouseout", hoverFunction59);
let img59 = document.getElementById("img-59");
let text59 = document.getElementById("text-59");
function hoverFunction59() {
  img59.classList.toggle("box-shadow");
  text59.classList.toggle("blue-text");
}
let Link60 = document.getElementById("link-60");
Link60.addEventListener("mouseover", hoverFunction60);
Link60.addEventListener("mouseout", hoverFunction60);
let img60 = document.getElementById("img-60");
let text60 = document.getElementById("text-60");
function hoverFunction60() {
  img60.classList.toggle("box-shadow");
  text60.classList.toggle("blue-text");
}
let Link61 = document.getElementById("link-61");
Link61.addEventListener("mouseover", hoverFunction61);
Link61.addEventListener("mouseout", hoverFunction61);
let img61 = document.getElementById("img-61");
let text61 = document.getElementById("text-61");
function hoverFunction61() {
  img61.classList.toggle("box-shadow");
  text61.classList.toggle("blue-text");
}
let Link62 = document.getElementById("link-62");
Link62.addEventListener("mouseover", hoverFunction62);
Link62.addEventListener("mouseout", hoverFunction62);
let img62 = document.getElementById("img-62");
let text62 = document.getElementById("text-62");
function hoverFunction62() {
  img62.classList.toggle("box-shadow");
  text62.classList.toggle("blue-text");
}
let Link63 = document.getElementById("link-63");
Link63.addEventListener("mouseover", hoverFunction63);
Link63.addEventListener("mouseout", hoverFunction63);
let img63 = document.getElementById("img-63");
let text63 = document.getElementById("text-63");
function hoverFunction63() {
  img63.classList.toggle("box-shadow");
  text63.classList.toggle("blue-text");
}
let Link64 = document.getElementById("link-64");
Link64.addEventListener("mouseover", hoverFunction64);
Link64.addEventListener("mouseout", hoverFunction64);
let img64 = document.getElementById("img-64");
let text64 = document.getElementById("text-64");
function hoverFunction64() {
  img64.classList.toggle("box-shadow");
  text64.classList.toggle("blue-text");
}
let Link65 = document.getElementById("link-65");
Link65.addEventListener("mouseover", hoverFunction65);
Link65.addEventListener("mouseout", hoverFunction65);
let img65 = document.getElementById("img-65");
let text65 = document.getElementById("text-65");
function hoverFunction65() {
  img65.classList.toggle("box-shadow");
  text65.classList.toggle("blue-text");
}
let Link66 = document.getElementById("link-66");
Link66.addEventListener("mouseover", hoverFunction66);
Link66.addEventListener("mouseout", hoverFunction66);
let img66 = document.getElementById("img-66");
let text66 = document.getElementById("text-66");
function hoverFunction66() {
  img66.classList.toggle("box-shadow");
  text66.classList.toggle("blue-text");
}
let Link67 = document.getElementById("link-67");
Link67.addEventListener("mouseover", hoverFunction67);
Link67.addEventListener("mouseout", hoverFunction67);
let img67 = document.getElementById("img-67");
let text67 = document.getElementById("text-67");
function hoverFunction67() {
  img67.classList.toggle("box-shadow");
  text67.classList.toggle("blue-text");
}
let Link68 = document.getElementById("link-68");
Link68.addEventListener("mouseover", hoverFunction68);
Link68.addEventListener("mouseout", hoverFunction68);
let img68 = document.getElementById("img-68");
let text68 = document.getElementById("text-68");
function hoverFunction68() {
  img68.classList.toggle("box-shadow");
  text68.classList.toggle("blue-text");
}
let Link69 = document.getElementById("link-69");
Link69.addEventListener("mouseover", hoverFunction69);
Link69.addEventListener("mouseout", hoverFunction69);
let img69 = document.getElementById("img-69");
let text69 = document.getElementById("text-69");
function hoverFunction69() {
  img69.classList.toggle("box-shadow");
  text69.classList.toggle("blue-text");
}
let Link70 = document.getElementById("link-70");
Link70.addEventListener("mouseover", hoverFunction70);
Link70.addEventListener("mouseout", hoverFunction70);
let img70 = document.getElementById("img-70");
let text70 = document.getElementById("text-70");
function hoverFunction70() {
  img70.classList.toggle("box-shadow");
  text70.classList.toggle("blue-text");
}
let Link71 = document.getElementById("link-71");
Link71.addEventListener("mouseover", hoverFunction71);
Link71.addEventListener("mouseout", hoverFunction71);
let img71 = document.getElementById("img-71");
let text71 = document.getElementById("text-71");
function hoverFunction71() {
  img71.classList.toggle("box-shadow");
  text71.classList.toggle("blue-text");
}
let Link72 = document.getElementById("link-72");
Link72.addEventListener("mouseover", hoverFunction72);
Link72.addEventListener("mouseout", hoverFunction72);
let img72 = document.getElementById("img-72");
let text72 = document.getElementById("text-72");
function hoverFunction72() {
  img72.classList.toggle("box-shadow");
  text72.classList.toggle("blue-text");
}
let Link73 = document.getElementById("link-73");
Link73.addEventListener("mouseover", hoverFunction73);
Link73.addEventListener("mouseout", hoverFunction73);
let img73 = document.getElementById("img-73");
let text73 = document.getElementById("text-73");
function hoverFunction73() {
  img73.classList.toggle("box-shadow");
  text73.classList.toggle("blue-text");
}
let Link74 = document.getElementById("link-74");
Link74.addEventListener("mouseover", hoverFunction74);
Link74.addEventListener("mouseout", hoverFunction74);
let img74 = document.getElementById("img-74");
let text74 = document.getElementById("text-74");
function hoverFunction74() {
  img74.classList.toggle("box-shadow");
  text74.classList.toggle("blue-text");
}
let Link75 = document.getElementById("link-75");
Link75.addEventListener("mouseover", hoverFunction75);
Link75.addEventListener("mouseout", hoverFunction75);
let img75 = document.getElementById("img-75");
let text75 = document.getElementById("text-75");
function hoverFunction75() {
  img75.classList.toggle("box-shadow");
  text75.classList.toggle("blue-text");
}
